<?php 
    class Contoh1 extends CI_Controller {
        public function index() {
            echo "<h1>Perkenalan</h1>";
            echo "Nama saya Ferrian Eka Septiawan
                  Saya tinggal di daerah Cibubur
                  olah raga yang saya sukai adalah
                  Sepakbola";
        }
    }
?>