        <footer>
            <a href="<?= base_url().'index.php/web' ?>">RentalBuku</a>
        </footer>
    </div>
</body>
</html>